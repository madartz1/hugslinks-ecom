# HUGSLinks Ecom Platform

Netlify-ready HUGS ecommerce platform with electric neon design, floating hearts, shop/cart, Stripe Checkout Sessions, Supabase admin dashboard, resources page, and Send a Hug page.

## Deploy
1. Upload this folder or push to GitHub.
2. Connect repo to Netlify.
3. Add environment variables:
   - STRIPE_SECRET_KEY
   - STRIPE_WEBHOOK_SECRET
   - SUPABASE_URL
   - SUPABASE_SERVICE_KEY
4. Run `database/schema.sql` in Supabase SQL editor.
5. Deploy.

## Frontend
Published from `/public`.

## Functions
Located in `/netlify/functions`.
